//
//  BirthControl.swift
//  myPill
//
//  Created by Keri Levesque on 2/3/20.
//  Copyright © 2020 Keri Levesque. All rights reserved.
//

import UIKit

class BirthControl {
    
    var name: String
    
    init(name: String) {
        self.name = name
    }
}


